const Aws = require('aws-sdk');
const S3 = new Aws.S3();

exports.handler = async(event) => {
    console.log(JSON.stringify(event));
    let param = {
        "Bucket": event.Records[0].s3.bucket.name,
        "Key": event.Records[0].s3.object.key
    }

    let data = S3.getObject(param).promise();
    console.log(data.Body.toString());

    return { statusCode: 200 };
}